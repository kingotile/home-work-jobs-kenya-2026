# Home Work Jobs — GitHub Pages-ready site

## Publish or update the existing GitHub Pages website
1. Open your `home-work-jobs` repository on GitHub.
2. Open the repository's **Code** tab.
3. Tap **Add file → Upload files**.
4. Extract this ZIP first, then upload the files inside this folder: `index.html`, `manifest.webmanifest`, `sw.js`, and `icon.svg` (README is optional).
5. Choose **Commit changes** and commit to `main`.
6. Open **Settings → Pages** and ensure deployment is from `main` and `/(root)`. GitHub Pages usually updates within a few minutes.
7. Open the site's published URL and refresh. If an older version remains, clear the site's browser cache or wait for deployment.

## What works
- Mobile-friendly tasks, practice quiz, completion points, local history, profile display name, reset progress, and installable/offline cache support on HTTPS hosting.
- Progress is stored only in this browser/device. There is no server account.

## Important payment limitation
M-Pesa deposits and withdrawals are **not connected**. GitHub Pages is static hosting and must not contain secret payment credentials. A real integration needs a secure backend, approved Safaricom Daraja access or an authorized payment provider, transaction callback verification, and a legitimate business/workflow. Do not represent sample points as cash or request a user's PIN/OTP.
